package com.sun.remote.controller.remote;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

/*
 * =====================================================================================
 * Summary:
 *
 * File: RemoteControlService.java
 * Author: Yanpeng.Sun
 * Create: 2019/6/11 17:25
 * =====================================================================================
 */
public class RemoteControlService extends Service implements RemoteControlAdapter{
    private Socket mSocket;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        initSocket();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public boolean initSocket() {
        try{
            mSocket = new Socket("127.0.0.1", 2001);
            //构建IO
            InputStream is = mSocket.getInputStream();
            OutputStream os = mSocket.getOutputStream();
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os));
            //向服务器端发送一条消息
            bw.write("socket connect:" + "\n");
            bw.flush();
            //读取服务器返回的消息
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String mess = br.readLine();
            System.out.println("服务器发来的消息：" + mess);
            if(mess.equals("connected")) return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean isRunning() {
        return mSocket.isConnected();
    }

    @Override
    public String accept() throws IOException {
        if(mSocket.isConnected()) {
            //读取服务器返回的消息
            BufferedReader br = new BufferedReader(new InputStreamReader(mSocket.getInputStream()));
            String mess = br.readLine();
            return mess;
        }
        return null;
    }

    @Override
    public void close() throws IOException {
        mSocket.close();
    }
}
